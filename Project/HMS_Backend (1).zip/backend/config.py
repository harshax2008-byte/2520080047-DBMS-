import os

class Config:
    """
    Set DATABASE_URL to point at MySQL, e.g.:
        mysql+pymysql://root:yourpassword@localhost:3306/hospital_management_system

    Falls back to a local SQLite file (hms.db) if unset, so you can run the
    API immediately without installing MySQL first.
    """
    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL", "sqlite:///hms.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-change-me")
