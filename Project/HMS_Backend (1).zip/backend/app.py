"""
MediCore HMS — Flask backend (v2)
==================================
Matches the multi-portal front-end (Admin / Doctor / Receptionist) action
for action: check-in, consult, admit/discharge, add room, add doctor,
add/toggle user, mark bill paid, and a per-patient aggregated record.

Run:
    pip install -r requirements.txt
    python seed.py
    python app.py        # http://localhost:5000
"""
from datetime import datetime, date
from flask import Flask, jsonify, request
from flask_cors import CORS

from config import Config
from models import (
    db, User, Doctor, Staff, Patient, Room,
    Appointment, Admission, Prescription, Billing
)

PRIORITY_RANK = {"Emergency": 0, "Critical": 1, "General": 2}


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    CORS(app)
    db.init_app(app)
    with app.app_context():
        db.create_all()
    register_routes(app)
    return app


def register_routes(app):

    # ---------------------------------------------------------------- AUTH
    @app.post("/api/login")
    def login():
        data = request.get_json(force=True) or {}
        role = data.get("role", "")
        username = data.get("username", "")
        doctor_id = data.get("doctorId")

        if role == "doctor" and doctor_id:
            d = Doctor.query.get(int(doctor_id))
            name = d.name if d else "Doctor"
        else:
            name = data.get("name") or username or role.capitalize()

        # Demo-friendly: any credentials "work". Tighten this (verify
        # password_hash, check users.is_active) before going to production.
        return jsonify({"ok": True, "user": {"username": username or "guest", "role": role, "name": name,
                                              "doctorId": doctor_id}})

    # ------------------------------------------------------------ PATIENTS
    @app.get("/api/patients")
    def list_patients():
        return jsonify([p.to_dict() for p in Patient.query.order_by(Patient.patient_id).all()])

    @app.post("/api/patients")
    def create_patient():
        d = request.get_json(force=True)
        p = Patient(name=d["name"], age=d.get("age"), gender=d.get("g", "M"),
                    contact_no=d.get("contact", ""), blood_group=d.get("blood"))
        db.session.add(p); db.session.commit()
        return jsonify(p.to_dict()), 201

    @app.get("/api/patients/<int:pid>/record")
    def patient_record(pid):
        """Everything the 'View record' modal needs, in one call."""
        p = Patient.query.get_or_404(pid)
        return jsonify({
            "patient": p.to_dict(),
            "appointments": [a.to_dict() for a in Appointment.query.filter_by(patient_id=pid)
                              .order_by(Appointment.appointment_date.desc()).all()],
            "prescriptions": [r.to_dict() for r in Prescription.query.filter_by(patient_id=pid)
                               .order_by(Prescription.prescription_id.desc()).all()],
            "admissions": [a.to_dict() for a in Admission.query.filter_by(patient_id=pid).all()],
            "billing": [b.to_dict() for b in Billing.query.filter_by(patient_id=pid).all()],
        })

    # ---------------------------------------------------------------- DOCTORS
    @app.get("/api/doctors")
    def list_doctors():
        return jsonify([d.to_dict() for d in Doctor.query.order_by(Doctor.doctor_id).all()])

    @app.post("/api/doctors")
    def create_doctor():
        d = request.get_json(force=True)
        name = d["name"] if d["name"].lower().startswith(("dr ", "dr.")) else "Dr. " + d["name"]
        doc = Doctor(name=name, specialization=d.get("dept", "General"), department=d.get("dept", "General"))
        db.session.add(doc); db.session.commit()
        return jsonify(doc.to_dict()), 201

    # ------------------------------------------------------------------ USERS
    @app.get("/api/users")
    def list_users():
        return jsonify([u.to_dict() for u in User.query.order_by(User.user_id).all()])

    @app.post("/api/users")
    def create_user():
        d = request.get_json(force=True)
        if User.query.filter_by(username=d["user"]).first():
            return jsonify({"error": "Username already taken."}), 409
        u = User(username=d["user"], password_hash="CHANGE_ME", role=d.get("role", "receptionist").lower(),
                  email=d["user"] + "@medicore.local", is_active=True)
        db.session.add(u); db.session.commit()
        return jsonify(u.to_dict()), 201

    @app.patch("/api/users/<int:uid>/toggle")
    def toggle_user(uid):
        u = User.query.get_or_404(uid)
        u.is_active = not u.is_active
        db.session.commit()
        return jsonify(u.to_dict())

    # ------------------------------------------------------------ APPOINTMENTS
    @app.get("/api/appointments")
    def list_appointments():
        return jsonify([a.to_dict() for a in Appointment.query
                         .order_by(Appointment.appointment_date, Appointment.appointment_time).all()])

    @app.get("/api/appointments/queue")
    def appointment_queue():
        today = datetime.now().date()
        appts = Appointment.query.filter_by(appointment_date=today).all()
        appts.sort(key=lambda a: (PRIORITY_RANK.get(a.priority, 3), a.appointment_time))
        return jsonify([a.to_dict() for a in appts])

    @app.post("/api/appointments")
    def create_appointment():
        d = request.get_json(force=True)
        a = Appointment(
            patient_id=d["pid"], doctor_id=d["did"],
            appointment_date=datetime.strptime(d["date"], "%Y-%m-%d").date(),
            appointment_time=datetime.strptime(d["time"], "%H:%M").time(),
            reason=d.get("reason", ""), priority=d.get("prio", "General"),
        )
        db.session.add(a); db.session.commit()
        return jsonify(a.to_dict()), 201

    @app.patch("/api/appointments/<int:aid>")
    def update_appointment(aid):
        """Body: {"status": "Checked-in" | "Completed" | "Cancelled"}"""
        a = Appointment.query.get_or_404(aid)
        d = request.get_json(force=True)
        if "status" in d:
            a.status = d["status"]
        db.session.commit()
        return jsonify(a.to_dict())

    @app.post("/api/appointments/<int:aid>/consult")
    def consult(aid):
        """Doctor's 'Consult' action: notes + optional prescription + optional follow-up."""
        a = Appointment.query.get_or_404(aid)
        d = request.get_json(force=True)
        a.status = "Completed"
        a.notes = d.get("notes", "")
        created_rx = None
        if d.get("meds"):
            created_rx = Prescription(patient_id=a.patient_id, doctor_id=a.doctor_id,
                                       appointment_id=a.appointment_id, medicines=d["meds"])
            db.session.add(created_rx)
        follow_up = None
        if d.get("followUpDays"):
            follow_date = date.today().fromordinal(date.today().toordinal() + int(d["followUpDays"]))
            follow_up = Appointment(patient_id=a.patient_id, doctor_id=a.doctor_id,
                                     appointment_date=follow_date, appointment_time=a.appointment_time,
                                     reason="Follow-up: " + (a.reason or ""), priority="General")
            db.session.add(follow_up)
        db.session.commit()
        return jsonify({"appointment": a.to_dict(),
                         "prescription": created_rx.to_dict() if created_rx else None,
                         "followUp": follow_up.to_dict() if follow_up else None})

    # ---------------------------------------------------------------- ROOMS
    @app.get("/api/rooms")
    def list_rooms():
        return jsonify([r.to_dict() for r in Room.query.order_by(Room.room_no).all()])

    @app.post("/api/rooms")
    def create_room():
        d = request.get_json(force=True)
        if Room.query.filter_by(room_no=d["no"]).first():
            return jsonify({"error": "Room already exists."}), 409
        r = Room(room_no=d["no"], room_type=d.get("type", "General"),
                  charge_per_day=d["rate"], status=d.get("status", "Available"))
        db.session.add(r); db.session.commit()
        return jsonify(r.to_dict()), 201

    # ------------------------------------------------------------ ADMISSIONS
    @app.get("/api/admissions")
    def list_admissions():
        return jsonify([a.to_dict() for a in Admission.query.all()])

    @app.post("/api/admissions")
    def admit():
        d = request.get_json(force=True)
        room = Room.query.get_or_404(d["room"])
        if room.status != "Available":
            return jsonify({"error": "Room is not available."}), 409
        if Admission.query.filter_by(patient_id=d["pid"], discharge_date=None).first():
            return jsonify({"error": "This patient is already admitted."}), 409
        adm = Admission(patient_id=d["pid"], room_no=d["room"], doctor_id=d["did"],
                         admission_date=d.get("date") or date.today(), diagnosis=d.get("dx", ""))
        room.status = "Occupied"
        db.session.add(adm); db.session.commit()
        return jsonify(adm.to_dict()), 201

    @app.patch("/api/admissions/<int:aid>/discharge")
    def discharge(aid):
        adm = Admission.query.get_or_404(aid)
        adm.discharge_date = date.today()
        room = Room.query.get(adm.room_no)
        if room:
            room.status = "Available"
        db.session.commit()
        return jsonify(adm.to_dict())

    # ------------------------------------------------------------ PRESCRIPTIONS
    @app.get("/api/prescriptions")
    def list_prescriptions():
        return jsonify([p.to_dict() for p in Prescription.query.order_by(Prescription.prescription_id.desc()).all()])

    @app.post("/api/prescriptions")
    def create_prescription():
        d = request.get_json(force=True)
        p = Prescription(patient_id=d["pid"], doctor_id=d["did"],
                          appointment_id=d.get("appointmentId"), medicines=d["meds"])
        db.session.add(p); db.session.commit()
        return jsonify(p.to_dict()), 201

    # ---------------------------------------------------------------- BILLING
    @app.get("/api/billing")
    def list_billing():
        return jsonify([b.to_dict() for b in Billing.query.order_by(Billing.billing_id.desc()).all()])

    @app.post("/api/billing")
    def create_billing():
        d = request.get_json(force=True)
        b = Billing(patient_id=d["pid"], amount=d["amt"],
                     payment_mode=d.get("mode", "Cash"), payment_status=d.get("status", "Pending"))
        db.session.add(b); db.session.commit()
        return jsonify(b.to_dict()), 201

    @app.patch("/api/billing/<int:bid>/pay")
    def mark_paid(bid):
        b = Billing.query.get_or_404(bid)
        b.payment_status = "Paid"
        db.session.commit()
        return jsonify(b.to_dict())

    # --------------------------------------------------------------- DASHBOARD
    @app.get("/api/dashboard/stats")
    def dashboard_stats():
        today = datetime.now().date()
        out = Billing.query.filter(Billing.payment_status != "Paid").all()
        return jsonify({
            "patients": Patient.query.count(),
            "appointmentsToday": Appointment.query.filter_by(appointment_date=today).count(),
            "roomsAvailable": Room.query.filter_by(status="Available").count(),
            "outstandingBills": len(out),
            "outstandingAmount": sum(float(b.amount) for b in out),
        })

    @app.get("/api/dashboard/revenue")
    def dashboard_revenue():
        """Revenue collected, grouped by payment mode — used on the admin overview."""
        paid = Billing.query.filter_by(payment_status="Paid").all()
        by_mode = {}
        for b in paid:
            by_mode[b.payment_mode] = by_mode.get(b.payment_mode, 0) + float(b.amount)
        return jsonify(by_mode)

    @app.get("/api/dashboard/workload")
    def dashboard_workload():
        """Per-doctor appointment/admission counts — used on the admin overview."""
        today = datetime.now().date()
        rows = []
        for d in Doctor.query.all():
            rows.append({
                "doctor": d.name, "dept": d.department,
                "today": Appointment.query.filter_by(doctor_id=d.doctor_id, appointment_date=today).count(),
                "total": Appointment.query.filter_by(doctor_id=d.doctor_id).count(),
                "inpatients": Admission.query.filter_by(doctor_id=d.doctor_id, discharge_date=None).count(),
            })
        return jsonify(rows)


app = create_app()

if __name__ == "__main__":
    app.run(debug=True, port=5000)
