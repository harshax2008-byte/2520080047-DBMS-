"""
Loads the same demo dataset used in frontend/index.html (dates are relative
to "today", same as the front-end's iso() helper), so the API and the
static prototype show identical numbers once wired together.

Run once:  python seed.py
"""
from datetime import date, time, timedelta
from app import create_app
from models import db, User, Doctor, Patient, Room, Appointment, Admission, Prescription, Billing

app = create_app()


def iso(offset_days):
    return date.today() + timedelta(days=offset_days)


with app.app_context():
    db.drop_all()
    db.create_all()

    # ---- users (matches the admin "Staff & users" seed list) ----
    users = [
        User(username="admin1", password_hash="CHANGE_ME", role="admin", email="admin1@medicore.local", is_active=True),
        User(username="dr.reddy", password_hash="CHANGE_ME", role="doctor", email="dr.reddy@medicore.local", is_active=True),
        User(username="dr.fatima", password_hash="CHANGE_ME", role="doctor", email="dr.fatima@medicore.local", is_active=True),
        User(username="priya.m", password_hash="CHANGE_ME", role="receptionist", email="priya.m@medicore.local", is_active=True),
        User(username="suresh.k", password_hash="CHANGE_ME", role="receptionist", email="suresh.k@medicore.local", is_active=True),
        User(username="ravi.t", password_hash="CHANGE_ME", role="receptionist", email="ravi.t@medicore.local", is_active=False),
    ]
    db.session.add_all(users); db.session.commit()

    # ---- doctors ----
    doctors = [
        Doctor(name="Dr. K. Reddy", specialization="Cardiology", department="Cardiology"),
        Doctor(name="Dr. A. Fatima", specialization="General Medicine", department="General Medicine"),
        Doctor(name="Dr. S. Narayan", specialization="Orthopedics", department="Orthopedics"),
        Doctor(name="Dr. Meera Pillai", specialization="Pediatrics", department="Pediatrics"),
        Doctor(name="Dr. Vivek Menon", specialization="Neurology", department="Neurology"),
    ]
    db.session.add_all(doctors); db.session.commit()

    # ---- patients ----
    patients_data = [
        ("T. Harsha Vardhan", 21, "M", "9000000001", "O+"),
        ("G. Anirudh", 21, "M", "9000000002", "B+"),
        ("S. Lakshmi", 58, "F", "9847213065", "A+"),
        ("Mohammed Ayaan", 34, "M", "9663210987", "B-"),
        ("P. Divya Sri", 27, "F", "9912345678", "O-"),
        ("R. Venkateswarlu", 64, "M", "9440098765", "AB+"),
        ("K. Anitha", 45, "F", "9887766554", "A-"),
        ("Syed Imran", 8, "M", "9123456780", "O+"),
        ("N. Bhargavi", 31, "F", "9556677889", "B+"),
        ("C. Ravi Teja", 52, "M", "9234567891", "AB-"),
        ("D. Sowmya", 19, "F", "9345678912", "O+"),
        ("V. Nagarjuna", 71, "M", "9456789123", "A+"),
        ("A. Keerthi", 29, "F", "9567891234", "B+"),
        ("M. Sai Kiran", 38, "M", "9678912345", "O-"),
    ]
    patients = [Patient(name=n, age=a, gender=g, contact_no=c, blood_group=b,
                        registered_on=iso(-30 + i * 2))
                for i, (n, a, g, c, b) in enumerate(patients_data)]
    db.session.add_all(patients); db.session.commit()

    # ---- rooms (pid > 0 means initially occupied, matching the front-end) ----
    rooms_data = [
        ("A-101", "General", 800, 1), ("A-102", "Private", 2500, 3), ("A-103", "Semi-Private", 1500, 0),
        ("A-104", "General", 800, 0), ("A-105", "Semi-Private", 1500, 6), ("B-201", "General", 800, 0),
        ("B-202", "Private", 2500, 0), ("B-203", "General", 800, -1), ("ICU-01", "ICU", 6000, 7),
        ("ICU-02", "ICU", 6000, 12), ("ICU-03", "ICU", 6000, 0), ("ICU-04", "ICU", 6000, -1),
    ]
    for no, typ, rate, p in rooms_data:
        status = "Occupied" if p > 0 else ("Maintenance" if p < 0 else "Available")
        db.session.add(Room(room_no=no, room_type=typ, charge_per_day=rate, status=status))
    db.session.commit()

    # ---- admissions, one per initially-occupied room ----
    dx_list = ["Cardiac observation", "Post-operative care", "Pneumonia", "Neurological monitoring", "Fracture recovery"]
    occupied = [(no, p) for no, _, _, p in rooms_data if p > 0]
    for i, (room_no, pid) in enumerate(occupied):
        db.session.add(Admission(patient_id=pid, room_no=room_no, doctor_id=(i % 5) + 1,
                                  diagnosis=dx_list[i % len(dx_list)], admission_date=iso(-(i + 1))))
    db.session.commit()

    # ---- appointments ----
    appts_data = [
        (1, 1, 0, "09:15", "Chest pain evaluation", "Critical", "Scheduled"),
        (8, 4, 0, "09:30", "High fever, breathing trouble", "Emergency", "Scheduled"),
        (2, 2, 0, "10:00", "Routine checkup", "General", "Checked-in"),
        (6, 3, 0, "10:30", "Knee pain follow-up", "General", "Scheduled"),
        (9, 5, 0, "11:00", "Recurring migraines", "Critical", "Scheduled"),
        (11, 2, 0, "11:30", "Fever and body ache", "General", "Scheduled"),
        (3, 1, 0, "08:30", "Post-op cardiac review", "Critical", "Completed"),
        (4, 3, -1, "15:00", "Fracture follow-up", "General", "Completed"),
        (5, 4, -1, "16:00", "Child vaccination", "General", "Completed"),
        (12, 5, 1, "09:00", "Memory loss evaluation", "Critical", "Scheduled"),
        (13, 2, 1, "09:45", "Prenatal checkup", "General", "Scheduled"),
        (14, 1, 1, "10:15", "Hypertension review", "General", "Scheduled"),
    ]
    for pid, did, off, t, reason, prio, status in appts_data:
        db.session.add(Appointment(patient_id=pid, doctor_id=did, appointment_date=iso(off),
                                    appointment_time=time.fromisoformat(t), reason=reason,
                                    priority=prio, status=status))
    db.session.commit()

    # ---- prescriptions ----
    presc_data = [
        (1, 1, "Aspirin 75mg 1-0-0 x 30 days; Atorvastatin 20mg 0-0-1 x 30 days", 0),
        (8, 4, "Paracetamol syrup 5ml 1-1-1 x 5 days; ORS as needed", 0),
        (6, 3, "Diclofenac 50mg 1-0-1 x 7 days; Calcium 500mg 1-0-0 x 30 days", 0),
        (9, 5, "Propranolol 40mg 1-0-1 x 15 days", 0),
        (3, 1, "Clopidogrel 75mg 1-0-0 x 90 days", 0),
        (4, 3, "Ibuprofen 400mg 1-0-1 x 5 days", -1),
        (11, 2, "Paracetamol 650mg 1-1-1 x 3 days", 0),
    ]
    for pid, did, meds, off in presc_data:
        db.session.add(Prescription(patient_id=pid, doctor_id=did, medicines=meds, date_issued=iso(off)))
    db.session.commit()

    # ---- billing ----
    bills_data = [
        (1, 3300, "Card", "Pending", 0), (3, 18500, "Insurance", "Partial", -2), (2, 600, "UPI", "Paid", 0),
        (8, 1200, "Cash", "Paid", 0), (6, 2450, "UPI", "Pending", 0), (9, 4100, "Card", "Pending", 0),
        (4, 7600, "Insurance", "Paid", -1), (5, 850, "Cash", "Paid", -1), (12, 9800, "Card", "Pending", 1),
    ]
    for pid, amt, mode, status, off in bills_data:
        db.session.add(Billing(patient_id=pid, amount=amt, payment_mode=mode,
                                payment_status=status, billing_date=iso(off)))
    db.session.commit()

    print("Seeded:", Patient.query.count(), "patients,", Doctor.query.count(), "doctors,",
          Appointment.query.count(), "appointments,", Room.query.count(), "rooms,",
          Admission.query.count(), "admissions,", Prescription.query.count(), "prescriptions,",
          Billing.query.count(), "bills,", User.query.count(), "users.")
