from flask_sqlalchemy import SQLAlchemy
from datetime import date

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = "users"
    user_id       = db.Column(db.Integer, primary_key=True)
    username      = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role          = db.Column(db.Enum("admin", "doctor", "receptionist", name="user_role"), nullable=False)
    email         = db.Column(db.String(100), unique=True, nullable=False)
    is_active     = db.Column(db.Boolean, default=True)
    created_at    = db.Column(db.DateTime, default=db.func.now())

    def to_dict(self):
        return {"id": self.user_id, "name": self.username, "user": self.username,
                "role": self.role.capitalize(), "email": self.email, "on": self.is_active}


class Doctor(db.Model):
    __tablename__ = "doctors"
    doctor_id        = db.Column(db.Integer, primary_key=True)
    user_id          = db.Column(db.Integer, db.ForeignKey("users.user_id"), unique=True, nullable=True)
    name             = db.Column(db.String(100), nullable=False)
    specialization   = db.Column(db.String(100), nullable=False)
    department       = db.Column(db.String(100))
    phone            = db.Column(db.String(15))
    email            = db.Column(db.String(100))
    years_experience = db.Column(db.Integer, default=0)

    def to_dict(self):
        return {"id": self.doctor_id, "name": self.name, "dept": self.department or self.specialization,
                "specialization": self.specialization, "phone": self.phone, "email": self.email}


class Staff(db.Model):
    __tablename__ = "staff"
    staff_id    = db.Column(db.Integer, primary_key=True)
    user_id     = db.Column(db.Integer, db.ForeignKey("users.user_id"), unique=True, nullable=True)
    name        = db.Column(db.String(100), nullable=False)
    designation = db.Column(db.String(50), nullable=False)
    department  = db.Column(db.String(100))
    phone       = db.Column(db.String(15))


class Patient(db.Model):
    __tablename__ = "patients"
    patient_id    = db.Column(db.Integer, primary_key=True)
    name          = db.Column(db.String(100), nullable=False)
    age           = db.Column(db.Integer, nullable=False)
    gender        = db.Column(db.Enum("M", "F", "Other", name="patient_gender"), nullable=False)
    contact_no    = db.Column(db.String(15), nullable=False)
    address       = db.Column(db.String(255))
    blood_group   = db.Column(db.String(5))
    registered_on = db.Column(db.Date, default=date.today)

    def to_dict(self):
        return {"id": self.patient_id, "name": self.name, "age": self.age, "g": self.gender,
                "contact": self.contact_no, "blood": self.blood_group,
                "reg": self.registered_on.isoformat() if self.registered_on else None}


class Room(db.Model):
    __tablename__ = "rooms"
    room_no        = db.Column(db.String(10), primary_key=True)
    room_type      = db.Column(db.Enum("General", "Semi-Private", "Private", "ICU", name="room_type"), nullable=False)
    floor          = db.Column(db.Integer, nullable=False, default=1)
    charge_per_day = db.Column(db.Numeric(10, 2), nullable=False)
    status         = db.Column(db.Enum("Available", "Occupied", "Maintenance", name="room_status"), default="Available")

    def to_dict(self):
        occ = Admission.query.filter_by(room_no=self.room_no, discharge_date=None).first()
        return {"no": self.room_no, "type": self.room_type, "rate": float(self.charge_per_day),
                "status": self.status, "pid": occ.patient_id if occ else 0}


class Appointment(db.Model):
    __tablename__ = "appointments"
    appointment_id   = db.Column(db.Integer, primary_key=True)
    patient_id       = db.Column(db.Integer, db.ForeignKey("patients.patient_id"), nullable=False)
    doctor_id        = db.Column(db.Integer, db.ForeignKey("doctors.doctor_id"), nullable=False)
    appointment_date = db.Column(db.Date, nullable=False)
    appointment_time = db.Column(db.Time, nullable=False)
    reason           = db.Column(db.String(255))
    priority         = db.Column(db.Enum("Emergency", "Critical", "General", name="appt_priority"), default="General")
    status           = db.Column(db.Enum("Scheduled", "Checked-in", "Completed", "Cancelled", name="appt_status"), default="Scheduled")
    notes            = db.Column(db.Text, nullable=True)

    patient = db.relationship("Patient")
    doctor  = db.relationship("Doctor")

    def to_dict(self):
        return {"id": self.appointment_id, "pid": self.patient_id, "did": self.doctor_id,
                "patient": self.patient.name if self.patient else None,
                "doctor": self.doctor.name if self.doctor else None,
                "date": self.appointment_date.isoformat(), "time": self.appointment_time.strftime("%H:%M"),
                "reason": self.reason, "prio": self.priority, "status": self.status, "notes": self.notes}


class Admission(db.Model):
    __tablename__ = "admissions"
    admission_id   = db.Column(db.Integer, primary_key=True)
    patient_id     = db.Column(db.Integer, db.ForeignKey("patients.patient_id"), nullable=False)
    room_no        = db.Column(db.String(10), db.ForeignKey("rooms.room_no"), nullable=False)
    doctor_id      = db.Column(db.Integer, db.ForeignKey("doctors.doctor_id"), nullable=False)
    admission_date = db.Column(db.Date, nullable=False)
    discharge_date = db.Column(db.Date, nullable=True)
    diagnosis      = db.Column(db.String(255))

    def to_dict(self):
        p = Patient.query.get(self.patient_id); d = Doctor.query.get(self.doctor_id)
        return {"id": self.admission_id, "pid": self.patient_id, "patient": p.name if p else None,
                "room": self.room_no, "did": self.doctor_id, "doctor": d.name if d else None,
                "dx": self.diagnosis, "date": self.admission_date.isoformat(),
                "out": self.discharge_date.isoformat() if self.discharge_date else ""}


class Prescription(db.Model):
    __tablename__ = "prescriptions"
    prescription_id = db.Column(db.Integer, primary_key=True)
    patient_id      = db.Column(db.Integer, db.ForeignKey("patients.patient_id"), nullable=False)
    doctor_id       = db.Column(db.Integer, db.ForeignKey("doctors.doctor_id"), nullable=False)
    appointment_id  = db.Column(db.Integer, db.ForeignKey("appointments.appointment_id"), nullable=True)
    medicines       = db.Column(db.Text, nullable=False)
    date_issued     = db.Column(db.Date, default=date.today)

    patient = db.relationship("Patient")
    doctor  = db.relationship("Doctor")

    def to_dict(self):
        return {"id": self.prescription_id, "pid": self.patient_id, "did": self.doctor_id,
                "patient": self.patient.name if self.patient else None,
                "doctor": self.doctor.name if self.doctor else None,
                "meds": self.medicines, "date": self.date_issued.isoformat()}


class Billing(db.Model):
    __tablename__ = "billing"
    billing_id     = db.Column(db.Integer, primary_key=True)
    patient_id     = db.Column(db.Integer, db.ForeignKey("patients.patient_id"), nullable=False)
    admission_id   = db.Column(db.Integer, db.ForeignKey("admissions.admission_id"), nullable=True)
    appointment_id = db.Column(db.Integer, db.ForeignKey("appointments.appointment_id"), nullable=True)
    amount         = db.Column(db.Numeric(10, 2), nullable=False)
    payment_mode   = db.Column(db.Enum("Cash", "Card", "UPI", "Insurance", name="pay_mode"), default="Cash")
    payment_status = db.Column(db.Enum("Paid", "Pending", "Partial", name="pay_status"), default="Pending")
    billing_date   = db.Column(db.Date, default=date.today)

    patient = db.relationship("Patient")

    def to_dict(self):
        return {"id": self.billing_id, "pid": self.patient_id,
                "patient": self.patient.name if self.patient else None,
                "amt": float(self.amount), "mode": self.payment_mode,
                "status": self.payment_status, "date": self.billing_date.isoformat()}
